interface TimedCallback {
    (number?: any): number | void;
}
export default TimedCallback;
