declare enum TimelineLevel {
    ERROR = 3,
    INFO = 6,
    DEBUG = 7
}
export default TimelineLevel;
