import SocketHooks from './socket_hooks';
declare var hooks: SocketHooks;
export default hooks;
