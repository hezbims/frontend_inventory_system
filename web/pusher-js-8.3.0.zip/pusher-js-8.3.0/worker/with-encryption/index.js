module.exports = require('../../dist/worker/pusher-with-encryption.worker.js');
