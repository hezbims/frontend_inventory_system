export declare var Dependencies: {};
