import { AuthTransport } from 'core/auth/auth_transports';
declare var jsonp: AuthTransport;
export default jsonp;
