export default function encode(s: any): string;
