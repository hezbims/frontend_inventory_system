declare var VERSION;
declare var CDN_HTTP;
declare var CDN_HTTPS;
declare var DEPENDENCY_SUFFIX;
declare var RUNTIME;
