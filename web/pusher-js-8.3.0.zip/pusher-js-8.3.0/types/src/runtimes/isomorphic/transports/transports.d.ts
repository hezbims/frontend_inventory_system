import TransportsTable from 'core/transports/transports_table';
export declare var streamingConfiguration: unknown;
export declare var pollingConfiguration: unknown;
declare var Transports: TransportsTable;
export default Transports;
