import { AuthTransport } from 'core/auth/auth_transports';
declare var fetchAuth: AuthTransport;
export default fetchAuth;
