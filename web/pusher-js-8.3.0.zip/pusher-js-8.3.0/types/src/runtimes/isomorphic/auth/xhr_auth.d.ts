import { AuthTransport } from 'core/auth/auth_transports';
declare const ajax: AuthTransport;
export default ajax;
