interface Window {
  WebSocket: any;
  MozWebSocket: any;
}
